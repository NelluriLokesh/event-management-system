using Microsoft.AspNetCore.Mvc;
using EventManagement.Models;
using System.Collections.Generic;
using System.Linq;

namespace EventManagement.Controllers
{
    public class EventController : Controller
    {
        public static List<Event> events = new List<Event>
        {
            new Event { Id = 1, Name = "Tech Conference", Date = DateTime.Now.AddDays(10), Description = "Annual tech meet-up" },
            new Event { Id = 2, Name = "Music Fest", Date = DateTime.Now.AddDays(20), Description = "Enjoy live music!" }
        };
        public static List<Passcode> pass = new List<Passcode>
        {
            new Passcode{passwords = 1234},
            new Passcode{passwords = 12345},
        };

        private static List<Registration> registrations = new List<Registration>();

        public IActionResult Index()
        {
            return View(events);
        }

        public IActionResult Notfountt()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Register(int id)
        {
            return View(new Registration { EventId = id });
        }

        [HttpPost]
        public IActionResult Register(Registration reg)
        {
            if (ModelState.IsValid)
            {
                reg.Id = registrations.Count + 1;
                registrations.Add(reg);
                return RedirectToAction("ThankYou");
            }

            return View(reg);
        }

        public IActionResult Passcode()
        {
            return View();
        }

        [HttpPost]
        public IActionResult checkpassword(Passcode passco)
        {
            if (pass.Any(p => p.passwords == passco.passwords))
            {
                return RedirectToAction("Create");
            }
            return RedirectToAction("Notfountt");
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult addCreate(Event model)
        {
            var new_data = new Event
            {
                Id = events.Count + 1,
                Name = model.Name,
                Date = model.Date,
                Description = model.Description
            };
            events.Add(new_data);
            return RedirectToAction("Index");
        }

        public IActionResult ThankYou()
        {
            return View();
        }

        public IActionResult RegisteredData()
        {
            return View(registrations);
        }
    }
}
