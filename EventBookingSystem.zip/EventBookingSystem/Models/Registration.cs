using System.ComponentModel.DataAnnotations;

namespace EventManagement.Models
{
    public class Registration
    {
        public int Id { get; set; }
        public int EventId { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [Phone]
        public string Phone { get; set; }
    }
}
