

using Microsoft.AspNetCore.Identity;

namespace EventManagement.Models
{
  public class Passcode
  {
    public int passwords { get; set; }
  }
}